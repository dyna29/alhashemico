<?php
/* 
 * Template Name: Investments
 */

get_header(); ?>
<!--========== PARALLAX ==========-->
<div class="parallax-window" data-parallax="scroll"
    data-image-src="<?php echo get_stylesheet_directory_uri(); ?>/img/plane-4.jpg">
    <div class="parallax-content container">
        <h1 class="carousel-title"><?php the_title(); ?></h1>
    </div>
</div>
<!--========== PARALLAX ==========-->

<!--========== PAGE LAYOUT ==========-->
<!-- About -->
<div class="content-lg container">
    <div class="row margin-b-20">
        <div class="col-sm-6">
            <h2>In order to grow and thrive in the current business climate, companies need to always adapt and
                innovate.</h2>
        </div>
    </div>
    <!--// end row -->

    <div class="row">
        <div class="col-sm-7 sm-margin-b-50">
            <div class="margin-b-30">
                <p>
                    Alhashemi Company was founded on the idea of being the frontrunners when it comes to
                    new and revolutionising ways to conduct business. For this reason, our goal is to invest in the latest
                    technologies and know-hows in order to provide the best possible products and services to our
                    customers.
                </p>
            </div>
        </div>
        <div class="col-sm-4 col-sm-offset-1" style="display: none;">
            <img class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/img/aviation.jpg"
                alt="Our Office">
        </div>
    </div>
    <!--// end row -->
</div>
<!-- End About -->
<!--========== END PAGE LAYOUT ==========-->
<?php get_footer();