<?php
/* 
 * Template Name: Foreign Exchange
 */

get_header(); ?>
<!--========== PARALLAX ==========-->
<div class="parallax-window" data-parallax="scroll"
    data-image-src="<?php echo get_stylesheet_directory_uri(); ?>/img/hand-pointing-currency-blockchain-technology-background-2.jpg">
    <div class="parallax-content container">
        <h1 class="carousel-title">
            <?php the_title(); ?>
        </h1>
    </div>
</div>
<!--========== PARALLAX ==========-->

<!--========== PAGE LAYOUT ==========-->

<!-- About -->
<div class="content-lg container">

    <div class="row">
        <div class="col-sm-7 sm-margin-b-50">
            <div class="margin-b-30">
                <p>
                    Established with the purpose of pioneering a new way forward in business through innovation,
                    Alhashemi Company has provided its customers with the best solutions or products
                </p>
            </div>
        </div>
        <div class="col-sm-4 col-sm-offset-1" style="display: none;">
            <img class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/img/forex.jpg"
                alt="Our Office">
        </div>
    </div>
    <!--// end row -->
</div>
<!-- End About -->
<!--========== END PAGE LAYOUT ==========-->
<?php get_footer();