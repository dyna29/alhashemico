<?php
/* 
 * Template Name: Solar Energy
 */

get_header(); ?>
<!--========== PARALLAX ==========-->
<div class="parallax-window" data-parallax="scroll"
    data-image-src="<?php echo get_stylesheet_directory_uri(); ?>/img/solar-panels-roof-solar-cell.jpg">
    <div class="parallax-content container">
        <h1 class="carousel-title">
            <?php the_title(); ?>
        </h1>
    </div>
</div>
<!--========== PARALLAX ==========-->

<!--========== PAGE LAYOUT ==========-->

<!-- About -->
<div class="content-lg container">
    <div class="row margin-b-20">
        <div class="col-sm-6">
            <h2>
                Alhashemi Company is devoted to the development, installation management, construction,
                investment, operation and maintenance activities of projects regarding photovoltaic solar facilities.
            </h2>
        </div>
    </div>
    <!--// end row -->

    <div class="row">
        <div class="col-sm-7 sm-margin-b-50">
            <div class="margin-b-30">
                <p>                    
                    Driven by the desire to always innovate and improve, we at Alhashemi Company perform research
                    and development projects in the pursue of discovering new installation systems.
                    Through our investments we have achieved the means to produce a clean technology
                    powerhouse ambition that has accelerated the access to low-cost, safety deployed, Megawatt-scale
                    solar energy. 
                </p>
                <p>                    
                    Through our visionary achievement we are transforming solar technologies to harness
                    the power of the Sun that meets all our energy needs in an accessible, affordable and abundant way.
                    Currently, our main focus is the development and sale of “turnkey” facilities, in which we provide
                    different types of facilities to meet the requirements of our customers. With the help of our
                    professional management team, which has vast experience in the implementation of complex
                    industrial projects, and highly qualified engineers, with extensive experiences in power electronics,
                    networking and communicational systems, there is no question or issue that cannot be solved.
                </p>
            </div>
        </div>
        <div class="col-sm-4 col-sm-offset-1" style="display: none;">
            <img class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/img/energy.jpg"
                alt="Our Office">
        </div>
    </div>
    <!--// end row -->
</div>
<!-- End About -->
<!--========== END PAGE LAYOUT ==========-->
<?php get_footer();