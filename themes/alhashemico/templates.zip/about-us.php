<?php
/* 
 * Template Name: About
 */

get_header(); ?>
<!--========== PARALLAX ==========-->
<div class="parallax-window" data-parallax="scroll"
    data-image-src="<?php echo get_stylesheet_directory_uri(); ?>/img/abt1.jpg">
    <div class="parallax-content container">
        <h1 class="carousel-title">
            <?php the_title(); ?>
        </h1>
    </div>
</div>
<!--========== PARALLAX ==========-->

<!--========== PAGE LAYOUT ==========-->

<!-- About -->
<div class="content-lg container">
    <div class="row margin-b-20">
        <div class="col-sm-6">
            <h2>Established with the purpose of pioneering a new way forward in business through innovation,
                Alhashemi Company has provided its customers with the best solutions or products.</h2>
        </div>
    </div>
    <!--// end row -->

    <div class="row">
        <div class="col-sm-7 sm-margin-b-50">
            <div class="margin-b-30">
                <p>
                    Through their partners and subsidiaries across the Middle East, Alhashemi Company is the best fit
                    for any
                    customer in the Energy, Oil and Gas or Aviation industry. With a team of highly experienced
                    individuals, we are confident that we will be able to assist with any issue or request.
                </p>
            </div>
        </div>
        <div class="col-sm-4 col-sm-offset-1" style="display: none;">
            <img class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/img/640x380/01.jpg"
                alt="Our Office">
        </div>
    </div>
    <!--// end row -->
</div>
<!-- End About -->
<!--========== END PAGE LAYOUT ==========-->
<?php get_footer();