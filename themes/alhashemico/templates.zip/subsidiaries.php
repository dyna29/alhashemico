<?php
/* 
 * Template Name: Subsidiaries
 */

get_header(); ?>
<!--========== PARALLAX ==========-->
<div class="parallax-window" data-parallax="scroll"
    data-image-src="<?php echo get_stylesheet_directory_uri(); ?>/img/1920x1080/01.jpg">
    <div class="parallax-content container">
        <h1 class="carousel-title"><?php the_title(); ?></h1>
        <p>
            In order to meet the demands of each of the clients across several industries, Alhashemi Company<br>
            has created subsidiaries that are best suited to tackle any issue that may arise
        </p>
    </div>
</div>
<!--========== PARALLAX ==========-->

<!-- Clients -->
<div class="bg-color-sky-light">
    <div class="content-lg container">
        <div class="row margin-b-20">
            <div class="col-sm-6">
                <h2>Our Subsidiaries</h2>
            </div>
        </div>
        <!-- Swiper Clients -->
        <div class="swiper-slider swiper-clients">
            <!-- Swiper Wrapper -->
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img class="swiper-clients-img"
                        src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/aviation 2.png" alt="Clients Logo">
                </div>
                <div class="swiper-slide">
                    <img class="swiper-clients-img"
                        src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/Exch Co 2.png" alt="Clients Logo">
                </div>
            </div>
            <!-- End Swiper Wrapper -->
        </div>
        <!-- End Swiper Clients -->
    </div>
</div>
<!-- End Clients -->
<!--========== END PAGE LAYOUT ==========-->
<?php get_footer();