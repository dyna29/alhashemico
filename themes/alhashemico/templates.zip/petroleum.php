<?php
/* 
 * Template Name: Petroleum
 */

get_header(); ?>
<!--========== PARALLAX ==========-->
<div class="parallax-window" data-parallax="scroll" data-image-src="<?php echo get_stylesheet_directory_uri(); ?>/img/1345c.jpg">
    <div class="parallax-content container">
        <h1 class="carousel-title"><?php the_title(); ?></h1>
        <p style="color: #ffffff;">
        Alhashemi Company has a varied collection of products in the Oil and Petroleum sector that<br>
        can be offered to satisfy all our clients needs
        </p>
    </div>
</div>
<!--========== PARALLAX ==========-->

<!--========== PAGE LAYOUT ==========-->
<!-- Features -->
<div class="section-seperator">
    <div class="content-lg container">
        <div class="row margin-b-20">
            <div class="col-sm-4 sm-margin-b-50">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".3s">
                    <h3>Distillates</h3>
                    <ul>
                        <li>Black Oil</li>
                        <li>Waste Oil</li>
                        <li>Mix Hydrocarbon Oil</li>
                        <li>Condensate</li>
                        <li>Light Distillates</li>
                        <li>Middle Distillates</li>
                        <li>Base Oil</li>
                        <li>Gas Oil</li>
                        <li>Lighter Cut</li>
                        <li>Carbon Black</li>
                        <li>Fuel Oil</li>
                        <li>Petrochemicals</li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-4 sm-margin-b-50">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".2s">
                    <h3>Oil Products</h3>
                    <ul>
                        <li>Asphalt</li>
                        <li>Base Oil</li>
                        <li>Condensate</li>
                        <li>Diesel Oil</li>
                        <li>Fuel Oil</li>
                        <li>Gasoil</li>
                        <li>Liquified Petroleum Gas</li>
                        <li>Kerosene</li>
                        <li>Vacuum Gas Oil</li>
                    </ul>                    
                </div>
            </div>
            <div class="col-sm-4">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".1s">
                    <h3>Solvents</h3>
                    <ul>
                        <li>Acetic Acid</li>
                        <li>Vinyl Acetate Monomer</li>
                        <li>n-Butyl Acetate</li>
                        <li>Ethyl Acetate</li>
                        <li>n-Hexane</li>
                        <li>White Spirit</li>
                        <li>Adipic Acid</li>
                        <li>Acetone</li>
                    </ul> 
                </div>
            </div>
        </div>
        <div class="row">            
            <div class="col-sm-4">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".1s">
                    <h3>Plastics</h3> 
                    <ul>
                        <li>Polyethylene</li>
                        <li>Polyethylene Terephthalate</li>
                        <li>Polypropylene</li>
                        <li>Phthalic Anhydride</li>
                        <li>Styrenes</li>
                        <li>Rubber and Rubber Products</li>
                    </ul> 
                </div>
            </div>
            <div class="col-sm-4">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".1s">
                    <h3>Octane and Gasoline</h3> 
                    <ul>
                        <li>Alkylate</li>
                        <li>C-9 Aromatics</li>
                        <li>Debenzenied PYGAS</li>
                        <li>Reformate</li>
                        <li>Raffinate</li>
                        <li>Gasoil</li>
                        <li>Gasoline</li>
                        <li>Isomerate</li>
                    </ul> 
                </div>
            </div>
        </div>
        <!--// end row -->
    </div>
</div>
<!-- End Features -->
<!--========== END PAGE LAYOUT ==========-->
<?php get_footer();