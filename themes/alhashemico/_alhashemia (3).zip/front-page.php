<?php
get_header();
?>
<!--========== SLIDER ==========-->
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <div class="container">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
            <li data-target="#carousel-example-generic" data-slide-to="3"></li>
        </ol>
    </div>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/img/plane-4.jpg"
                alt="Slider Image">
            <div class="container">
                <div class="carousel-centered">
                    <div class="">
                        <h1 class="carousel-title">An investment<br>that takes you<br>to great heights</h1>
                        <p style="color: #ffffff;">Established with the purpose of pioneering a new way forward in
                            business through innovation, Alhashemi Company has provided its customers with the best
                            solutions or products</p>
                    </div>
                    <a href="<?php echo site_url();?>/investments"
                        class="btn-theme btn-theme-sm btn-white-brd text-uppercase">Explore</a>
                </div>
            </div>
        </div>
        <div class="item">
            <img class="img-responsive"
                src="<?php echo get_stylesheet_directory_uri(); ?>/img/hand-pointing-currency-blockchain-technology-background-2.jpg"
                alt="Slider Image">
            <div class="container">
                <div class="carousel-centered">
                    <div class="">
                        <h2 class="carousel-title">Making you<br>financially strong</h2>
                        <p style="color: #ffffff;">Established with the purpose of pioneering a new way forward in
                            business through innovation, Alhashemi Company has provided its customers with the best
                            solutions or products</p>
                    </div>
                    <a href="<?php echo site_url();?>/foreign-exchange/"
                        class="btn-theme btn-theme-sm btn-white-brd text-uppercase">Explore</a>
                </div>
            </div>
        </div>
        <div class="item">
            <img class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/img/1345c.jpg"
                alt="Slider Image">
            <div class="container">
                <div class="carousel-centered">
                    <div class="">
                        <h2 class="carousel-title">From potential<br>to production</h2>
                        <p style="color: #ffffff;">
                            Established with the purpose of pioneering a new way forward in business through innovation,
                            Alhashemi Company has provided its customers with the best solutions or products
                        </p>
                    </div>
                    <a href="<?php echo site_url();?>/petroleum/"
                        class="btn-theme btn-theme-sm btn-white-brd text-uppercase">Explore</a>
                </div>
            </div>
        </div>
        <div class="item">
            <img class="img-responsive"
                src="<?php echo get_stylesheet_directory_uri(); ?>/img/solar-panels-roof-solar-cell.jpg"
                alt="Slider Image">
            <div class="container">
                <div class="carousel-centered">
                    <div class="">
                        <h2 class="carousel-title">Empowering<br>generations to come</h2>
                        <p style="color: #ffffff;">
                            Established with the purpose of pioneering a new way forward in business through innovation,
                            Alhashemi Company has provided its customers with the best solutions or products
                        </p>
                    </div>
                    <a href="<?php echo site_url();?>/solar-energy/"
                        class="btn-theme btn-theme-sm btn-white-brd text-uppercase">Explore</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--========== SLIDER ==========-->

<!--========== PAGE LAYOUT ==========-->

<!-- About -->
<div class="content-sm container">
    <div class="row">
        <div class="col-sm-6">
            <h2>About</h2>
        </div>
    </div>
    <!--// end row -->

    <div class="row">
        <div class="col-sm-6 sm-margin-b-50">
            <h3>
                Established with the purpose of pioneering a new way forward in business through innovation,
                Alhashemi Company has provided its customers with the best solutions or products.
            </h3>
            <div class="margin-b-30">
                <p>
                    Through their partners and subsidiaries across the Middle East, Alhashemi Company is the best fit
                    for any
                    customer in the Energy, Oil and Gas or Aviation industry. With a team of highly experienced
                    individuals, we are confident that we will be able to assist with any issue or request.
                </p>
            </div>
        </div>
        <div class="col-sm-5 col-sm-offset-1">
            <img class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/img/group-diverse-people-having-business-meeting.jpg"
                alt="Our Office">
        </div>
    </div>
    <!--// end row -->
</div>
<!-- End About -->



<!-- Work -->
<div class="bg-color-sky-light overflow-h">
    <div class="content-lg container">
        <div class="row margin-b-40">
            <div class="col-sm-6">
                <h2>Our Services</h2>
                <p>
                    Established with the purpose of pioneering a new way forward in business through innovation,
                    Alhashemi Company has provided its customers with the best solutions or products
                </p>
            </div>
        </div>
        <!--// end row -->

        <!-- Masonry Grid -->
        <div class="masonry-grid">
            <div class="masonry-grid-sizer col-xs-6 col-sm-6 col-md-1"></div>
            <div class="masonry-grid-item col-xs-12 col-sm-6 col-md-8">
                <!-- Work -->
                <div class="work wow fadeInUp" data-wow-duration=".3" data-wow-delay=".1s">
                    <div class="work-overlay">
                        <img class="full-width img-responsive"
                            src="<?php echo get_stylesheet_directory_uri(); ?>/img/investment.jpg"
                            alt="Portfolio Image">
                    </div>
                    <div class="work-content">
                        <h3 class="color-white margin-b-5">Investment</h3>
                        <p class="color-white margin-b-0">An investment that takes you to great heights</p>
                    </div>
                    <a class="content-wrapper-link" href="<?php echo site_url();?>/investments/"></a>
                </div>
                <!-- End Work -->
            </div>
            <div class="masonry-grid-item col-xs-6 col-sm-6 col-md-4">
                <!-- Work -->
                <div class="work wow fadeInUp" data-wow-duration=".3" data-wow-delay=".2s">
                    <div class="work-overlay">
                        <img class="full-width img-responsive"
                            src="<?php echo get_stylesheet_directory_uri(); ?>/img/aviation.jpg" alt="Portfolio Image">
                    </div>
                    <div class="work-content">
                        <h3 class="color-white margin-b-5">Aviation</h3>
                        <p class="color-white margin-b-0">Reaching new heights together.</p>
                    </div>
                    <a class="content-wrapper-link" href="<?php echo site_url();?>/aviation/"></a>
                </div>
                <!-- End Work -->
            </div>
            <div class="masonry-grid-item col-xs-6 col-sm-6 col-md-4">
                <!-- Work -->
                <div class="work wow fadeInUp" data-wow-duration=".3" data-wow-delay=".3s">
                    <div class="work-overlay">
                        <img class="full-width img-responsive"
                            src="<?php echo get_stylesheet_directory_uri(); ?>/img/petroleum.jpg" alt="Portfolio Image">
                    </div>
                    <div class="work-content">
                        <h3 class="color-white margin-b-5">Petroleum</h3>
                        <p class="color-white margin-b-0">From potential to production.</p>
                    </div>
                    <a class="content-wrapper-link" href="<?php echo site_url();?>/petroleum/"></a>
                </div>
                <!-- End Work -->
            </div>
            <div class="masonry-grid-item col-xs-6 col-sm-6 col-md-4">
                <!-- Work -->
                <div class="work wow fadeInUp" data-wow-duration=".3" data-wow-delay=".4s">
                    <div class="work-overlay">
                        <img class="full-width img-responsive"
                            src="<?php echo get_stylesheet_directory_uri(); ?>/img/energy.jpg" alt="Energy Image">
                    </div>
                    <div class="work-content">
                        <h3 class="color-white margin-b-5">Energy</h3>
                        <p class="color-white margin-b-0">Empowering generations to come.</p>
                    </div>
                    <a class="content-wrapper-link" href="<?php echo site_url();?>/solar-energy/"></a>
                </div>
                <!-- End Work -->
            </div>
            <div class="masonry-grid-item col-xs-6 col-sm-6 col-md-4">
                <!-- Work -->
                <div class="work wow fadeInUp" data-wow-duration=".3" data-wow-delay=".5s">
                    <div class="work-overlay">
                        <img class="full-width img-responsive"
                            src="<?php echo get_stylesheet_directory_uri(); ?>/img/forex.jpg" alt="Portfolio Image">
                    </div>
                    <div class="work-content">
                        <h3 class="color-white margin-b-5">Foreign Exchange</h3>
                        <p class="color-white margin-b-0">Making you financially strong.</p>
                    </div>
                    <a class="content-wrapper-link" href="<?php echo site_url();?>/foreign-exchange/"></a>
                </div>
                <!-- End Work -->
            </div>
        </div>
        <!-- End Masonry Grid -->
    </div>
</div>
<!-- End Work -->

<!-- Service -->
<div class="bg-color-sky-light" data-auto-height="true" style="display: none;">
    <div class="content-lg container">
        <div class="row margin-b-20">
            <div class="col-sm-6">
                <h2>Our Services</h2>
            </div>
        </div>
        <div class="row row-space-1 margin-b-2">
            <div class="col-sm-4 sm-margin-b-2">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".3s">
                    <div class="service" data-height="height">
                        <div class="service-element">
                            <i class="service-icon icon-chemistry"></i>
                        </div>
                        <div class="service-info">
                            <h3>Investment</h3>
                        </div>
                        <a href="#" class="content-wrapper-link"></a>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 sm-margin-b-2">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".2s">
                    <div class="service" data-height="height">
                        <div class="service-element">
                            <i class="service-icon icon-plane"></i>
                        </div>
                        <div class="service-info">
                            <h3>Aviation</h3>
                        </div>
                        <a href="#" class="content-wrapper-link"></a>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".1s">
                    <div class="service" data-height="height">
                        <div class="service-element">
                            <i class="service-icon icon-badge"></i>
                        </div>
                        <div class="service-info">
                            <h3>Petroleum</h3>
                        </div>
                        <a href="#" class="content-wrapper-link"></a>
                    </div>
                </div>
            </div>
        </div>
        <!--// end row -->

        <div class="row row-space-1">
            <div class="col-sm-6 sm-margin-b-2">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".4s">
                    <div class="service" data-height="height">
                        <div class="service-element">
                            <i class="service-icon icon-notebook"></i>
                        </div>
                        <div class="service-info">
                            <h3>Energy</h3>
                        </div>
                        <a href="#" class="content-wrapper-link"></a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 sm-margin-b-2">
                <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".5s">
                    <div class="service" data-height="height">
                        <div class="service-element">
                            <i class="service-icon icon-speedometer"></i>
                        </div>
                        <div class="service-info">
                            <h3>Tours & Travels</h3>
                        </div>
                        <a href="#" class="content-wrapper-link"></a>
                    </div>
                </div>
            </div>
        </div>
        <!--// end row -->
    </div>
</div>
<!-- End Service -->

<!-- Latest Products -->
<div class="content-lg container" style="display: none;">
    <div class="row margin-b-40">
        <div class="col-sm-6">
            <h2>Latest Products</h2>
            <p>Established with the purpose of pioneering a new way forward in business through innovation, Alhashemi
                Company has provided its customers with the best solutions or products</p>
        </div>
    </div>
    <!--// end row -->

    <div class="row">
        <!-- Latest Products -->
        <div class="col-sm-4 sm-margin-b-50">
            <div class="margin-b-20">
                <div class="wow zoomIn" data-wow-duration=".3" data-wow-delay=".1s">
                    <img class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/img/970x647/01.jpg"
                        alt="Latest Products Image">
                </div>
            </div>
            <h4><a href="#">Triangle Roof</a> <span class="text-uppercase margin-l-20">Management</span></h4>
            <p>
                Established with the purpose of pioneering a new way forward in business through innovation, Alhashemi
                Company has provided its customers with the best solutions or products
            </p>
            <a class="link" href="#">Read More</a>
        </div>
        <!-- End Latest Products -->

        <!-- Latest Products -->
        <div class="col-sm-4 sm-margin-b-50">
            <div class="margin-b-20">
                <div class="wow zoomIn" data-wow-duration=".3" data-wow-delay=".1s">
                    <img class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/img/970x647/02.jpg"
                        alt="Latest Products Image">
                </div>
            </div>
            <h4><a href="#">Curved Corners</a> <span class="text-uppercase margin-l-20">Developmeny</span></h4>
            <p>
                Established with the purpose of pioneering a new way forward in business through innovation, Alhashemi
                Company has provided its customers with the best solutions or products
            </p>
            <a class="link" href="#">Read More</a>
        </div>
        <!-- End Latest Products -->

        <!-- Latest Products -->
        <div class="col-sm-4 sm-margin-b-50">
            <div class="margin-b-20">
                <div class="wow zoomIn" data-wow-duration=".3" data-wow-delay=".1s">
                    <img class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/img/970x647/03.jpg"
                        alt="Latest Products Image">
                </div>
            </div>
            <h4><a href="#">Bird On Green</a> <span class="text-uppercase margin-l-20">Design</span></h4>
            <p>
                Established with the purpose of pioneering a new way forward in business through innovation, Alhashemi
                Company has provided its customers with the best solutions or products
            </p>
            <a class="link" href="#">Read More</a>
        </div>
        <!-- End Latest Products -->
    </div>
    <!--// end row -->
</div>
<!-- End Latest Products -->

<!-- Clients -->
<div class="bg-color-sky-light">
    <div class="content-lg container">
        <div class="row margin-b-20">
            <div class="col-sm-6">
                <h2>Our Subsidiaries</h2>
            </div>
        </div>
        <!-- Swiper Clients -->
        <div class="swiper-slider swiper-clients">
            <!-- Swiper Wrapper -->
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img class="swiper-clients-img"
                        src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/aviation 2.png" alt="Clients Logo">
                </div>
                <div class="swiper-slide">
                    <img class="swiper-clients-img"
                        src="<?php echo get_stylesheet_directory_uri(); ?>/img/logos/Exch Co 2.png" alt="Clients Logo">
                </div>
            </div>
            <!-- End Swiper Wrapper -->
        </div>
        <!-- End Swiper Clients -->
    </div>
</div>
<!-- End Clients -->

<?php
get_footer();