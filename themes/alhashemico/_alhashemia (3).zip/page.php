<?php
get_header(); ?>
<!--========== PARALLAX ==========-->
<div class="parallax-window" data-parallax="scroll"
    data-image-src="<?php echo get_the_post_thumbnail_url(); ?>">
    <div class="parallax-content container">
        <h1 class="carousel-title">
            <?php the_title(); ?>
        </h1>
    </div>
</div>
<!--========== PARALLAX ==========-->

<!--========== PAGE LAYOUT ==========-->

<!-- About -->
<div class="content-lg container">
    <div class="row">
        <div class="col-sm-7 sm-margin-b-50">
            <div class="margin-b-30">
                <?php the_content(); ?>
            </div>
        </div>
    </div>
    <!--// end row -->
</div>
<!-- End About -->
<!--========== END PAGE LAYOUT ==========-->
<?php get_footer();