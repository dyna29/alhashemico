// Initialize modules
// Importing specific gulp API functions lets us write them below as series() instead of gulp.series()
const { src, dest, watch, series, parallel } = require('gulp');

// Importing all the Gulp-related packages we want to use
var babel =require('gulp-babel');
const sourcemaps = require('gulp-sourcemaps');
const sass = require('gulp-sass');
const concat = require('gulp-concat');
const uglify = require('gulp-uglify');
var terser = require('gulp-terser');
var rename = require('gulp-rename');
var cleanCSS = require('gulp-clean-css');
var gulp = require('gulp');

// File paths
const files = { 
    scssPath: 'sass/**/**/*.scss',
    jsPath: 'js/layout.js'
}

function clean() {
  return del([ 'assets' ]);
}

// Sass task: compiles the style.scss file into style.css
function scssTask(){  
    return gulp.src(files.scssPath)
    .pipe(sass())
    .pipe(cleanCSS())
    // pass in options to the stream
    .pipe(rename({
      basename: 'layout.min'
    }))
    .pipe(gulp.dest('./css/')); 
}

// JS task: concatenates and uglifies JS files to script.js
function jsTask(){
    return gulp.src(files.jsPath, { sourcemaps: false })
    .pipe(concat('layout.min.js'))
    .pipe(gulp.dest('./js/')); 
}

// Watch task: watch SCSS and JS files for changes
// If any change, run scss and js tasks simultaneously
function watchTask(){
    watch([files.scssPath, files.jsPath],
        {interval: 100, usePolling: true}, //Makes docker work
        series(
            parallel(scssTask, jsTask)
        )
    );    
}

// Export the default Gulp task so it can be run
// Runs the scss and js tasks simultaneously
// then runs cacheBust, then watch task
exports.default = series(
    parallel(jsTask), 
    parallel(scssTask), 
    watchTask
);