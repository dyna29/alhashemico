<?php
if ( ! function_exists( 'alhashemia_setup' ) ) :

	function alhashemia_setup() {
		/*
		 * Textdomain for translation
		 */
		load_theme_textdomain( 'alhashemia', get_template_directory() . '/languages' );

		/*
		 * Let WordPress manage the document title.
		 */
		add_theme_support( 'title-tag' );

		// This theme uses wp_nav_menu() in two locations.
		register_nav_menus(
			array(
				'menu-1' => __( 'Primary', 'alhashemia' ),
				'footer' => __( 'Footer Menu', 'alhashemia' ),
			)
		);

		// featured image support
		add_theme_support( 'post-thumbnails', array( 'post', 'page' ) );

	}
endif;
add_action( 'after_setup_theme', 'alhashemia_setup' );

/**
 * Enqueue scripts and styles.
 */
function alhashemia_scripts() {
	wp_enqueue_style( 'alhashemia-style', get_stylesheet_uri() );		
	wp_enqueue_style( 'alhashemia-animate', get_theme_file_uri() . '/css/animate.css' );	
	wp_enqueue_style( 'alhashemia-swiper', get_theme_file_uri() . '/vendor/swiper/css/swiper.min.css' );	
	wp_enqueue_style( 'alhashemia-fonts', 'http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700' );
	wp_enqueue_style( 'alhashemia-icons', get_theme_file_uri() . '/vendor/simple-line-icons/simple-line-icons.min.css' );	
	wp_enqueue_style( 'alhashemia-bootstrap', get_theme_file_uri() . '/vendor/bootstrap/css/bootstrap.min.css' );	
	wp_enqueue_style( 'alhashemia-layout', get_theme_file_uri() . '/css/layout.min.css' );	

	wp_enqueue_script( 'alhashemia-jquery', get_theme_file_uri() . '/vendor/jquery.min.js' , array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-jquery-migrate', get_theme_file_uri() . '/vendor/jquery-migrate.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-bootstrap-js', get_theme_file_uri() . '/vendor/bootstrap/js/bootstrap.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-jquery-easing-js', get_theme_file_uri() . '/vendor/jquery.easing.js' , array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-jquery-back-to-top-js', get_theme_file_uri() . '/vendor/jquery.back-to-top.js' , array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-jquery-smooth-scroll-js', get_theme_file_uri() . '/vendor/jquery.smooth-scroll.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-jquery-wow--js', get_theme_file_uri() . '/vendor/jquery.wow.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-swiper-js', get_theme_file_uri() . '/vendor/swiper/js/swiper.jquery.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-masonry-js', get_theme_file_uri() . '/vendor/masonry/jquery.masonry.pkgd.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-masonry-imagesloaded-js', get_theme_file_uri() . '/vendor/masonry/imagesloaded.pkgd.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-layout-js', get_theme_file_uri() . '/js/layout.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-wow-js-1', get_theme_file_uri() . '/js/components/wow.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-swiper-js-1', get_theme_file_uri() . '/js/components/swiper.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-masonry-js-1', get_theme_file_uri() . '/js/components/masonry.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'alhashemia-parallax-js', get_theme_file_uri() . '/vendor/jquery.parallax.min.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'alhashemia_scripts' );

/*------------------------------------------
REGISTER Gallery POST TYPE
------------------------------------------*/
$args = array(
	'labels' => array(
					'name' => 'Gallery',
					'singular_name' => 'gallery',
					'add_new_item' => 'Add New Gallery',
					'edit_item' => 'Edit galery',
					'new_item' => 'New Gallery',
					'view_item' => 'View Gallery',
					'search_items' => 'Search Gallery',
					'not_found' => 'No Gallery found',
					'not_found_in_trash' => 'No Gallery found in Trash',
					'all_items' => 'All Galleries',
				),
	'show_ui' => true,
	'show_in_menu' => true,
	'menu_icon' => 'dashicons-format-quote',
	'supports' => array ( 'title', 'editor', 'thumbnail'),
	'public' => true,
	'has_archive' => true,
	'capability_type'    => 'post', 	
);
register_post_type( 'gallery', $args ); 

$labels_gallery_taxonomy = array(
'name'              => 'Year',
'singular_name'     => 'Year',
'search_items'      => 'Search Year',
'all_items'         => 'All Years',
'parent_item'       => 'Parent Year',
'parent_item_colon' => 'Parent Year:',
'edit_item'         => 'Edit Year',
'update_item'       => 'Update Year',
'add_new_item'      => 'Add New Year',
'new_item_name'     => 'New Year',
'menu_name'         => 'Year',
);

$args_gallery_taxonomy = array(
'hierarchical'      => true,
'labels'            => $labels_gallery_taxonomy,
'show_ui'           => true,
'show_admin_column' => true,
'query_var'         => true,
'rewrite'           => array( 'slug' => 'home-slider-taxonomy' ),
);

register_taxonomy( 'gallery-year', array( 'gallery' ),$args_gallery_taxonomy );


/*--------------------------------------------
Gallery Album
---------------------------------------------*/
add_action( 'add_meta_boxes', 'gallery_meta_box' );  
function gallery_meta_box() {
	$screens = array( 'gallery' );
	foreach ( $screens as $screen ) {
		add_meta_box(
			'gallery_metabox',
			__( 'Image Gallery - <span style="font-weight:normal;">Upload Multiple images for the Album.</span>', 'gallery' ),
			'gallery_meta_box_callback',
			$screen,
			'normal',
			'high'
		);
	}
} 
function gallery_meta_box_callback( $post ) {  
	$gallery_image_url = get_post_meta($post->ID,"gallery_image_url",true);	?>
	
	<fieldset>
		<legend>Images</legend>
		<div class="repeater_box">
			<div class="repeater_container">
				<?php if(!empty($gallery_image_url)){ ?>
					<?php foreach($gallery_image_url as $k=>$l) { ?>
						<div class="item logo">
							<span onclick="remove_item(this)">X</span>
							<img src="<?php echo $l; ?>">
							<input type="hidden" name="gallery_image_url[]" value="<?php echo $l; ?>">														
						</div>
					<?php } ?>	
				<?php } ?>	
			</div>
			<input type="button" value="Add+" class="button button-primary logo_upload">
		</div>
	</fieldset>
	
	<style>
		.repeater_container .item{ 
			border: 1px solid #c1c1c1;
			padding: 10px;
			margin: 5px;
			position: relative;
			display:inline-block;
			padding-right:20px;
		}	
		.repeater_container .item > span{  
			position: absolute; 
			right: 0px;
			background: red;
			font-weight: bold;
			font-size: 15px;
			color: #fff;
			padding: 2px 6px;
			cursor: pointer;
			top: 0px;
		}
		.repeater_container .item.logo{ 
			width:149px;
			height:110px;
			overflow:hidden;
			padding:0px;
		}
		.repeater_container .item.logo img{
			max-width:100%;
		}
		.repeater_container .item.logo .img_bg{ 
			width:100%;
			height:100%;
			background-size: cover !important;
			background-position: center !important;
		}
	</style>
	
	<script> 
		function remove_item(dis){
			jQuery(dis).parent('.item').remove();
		}
	
		jQuery(".logo_upload").click(function(){
			var elem=jQuery(this);
			file_frame = wp.media.frames.file_frame = wp.media({
				multiple: false  
			});
			
			file_frame.on( 'select', function() {
				var attachment = file_frame.state().get('selection').first().toJSON();
				imgid =attachment.id;
				imgurl = attachment.url;
				jQuery(elem).siblings('.repeater_container').append(''+'<div class="item logo">'+'<span onclick="remove_item(this)">X</span>'+'<img src="'+imgurl+'">'+'<input type="hidden" name="gallery_image_url[]" value="'+imgurl+'">'+'</div>'+'');
			});
			file_frame.open();
		});
	</script><?php
}
add_action( 'save_post', 'gallery_save_meta_box' );
function gallery_save_meta_box( $post_id ) {
	if(isset($_POST['gallery_image_url']))
			update_post_meta($post_id, "gallery_image_url", $_POST['gallery_image_url']);	
		else{
			if(!defined( 'DOING_AJAX' ))
				update_post_meta($post_id, "gallery_image_url",'');
		}
	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
		if ( ! current_user_can( 'edit_page', $post_id ) ) {
			return;
		}
	} 
	else {
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	}
	
 } 

 function pippin_get_image_id($image_url) {
    global $wpdb;
    $attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url )); 
        return $attachment[0]; 
}

@ini_set( 'upload_max_size' , '64M' );
@ini_set( 'post_max_size', '64M');
@ini_set( 'max_execution_time', '300' );