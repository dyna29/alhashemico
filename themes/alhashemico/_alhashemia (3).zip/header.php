<!doctype html>
<html <?php language_attributes(); ?>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title><?php wp_title('|', true, 'right'); ?></title>
	<link rel="shortcut icon" type="image/ico" href="<?php echo get_stylesheet_directory_uri(); ?>/img/cropped-favicon-270x270.png">
	<link rel="apple-touch-icon" type="image/png" href="<?php echo get_stylesheet_directory_uri(); ?>/img/cropped-favicon-270x270.png">
	<link rel="icon" type="image/png" href="<?php echo get_stylesheet_directory_uri(); ?>/img/cropped-favicon-270x270.png">

    <script>
		//favicon normal and dark mode
		var darkModeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
		handleDarkmode(darkModeMediaQuery);
		function handleDarkmode(e){
			var darkModeOn = e.matches; 
			var favicon = document.querySelector('link[rel="shortcut icon"]'); 
			var largeFavicon = document.querySelector('link[rel="icon"]'); 
			if(!favicon || !largeFavicon){
				return; 
			}
			// replace icons with dark/light themes as appropriate
			if(darkModeOn){
				favicon.href = '<?php echo get_stylesheet_directory_uri(); ?>/favicon-dark.png';
				largeFavicon.href = '<?php echo get_stylesheet_directory_uri(); ?>/favicon-dark.png';
			}else{
				favicon.href = '<?php echo get_stylesheet_directory_uri(); ?>/favicon.png';
				largeFavicon.href = '<?php echo get_stylesheet_directory_uri(); ?>/favicon.png';
			}
		}
		darkModeMediaQuery.addListener(handleDarkmode);
	</script>
        
	<?php wp_head(); ?>
</head>

<body class="no-js">
<?php wp_body_open(); ?>

<!--========== HEADER ==========-->
<header class="header navbar-fixed-top">
    <!-- Navbar -->
    <nav class="navbar" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="menu-container">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="toggle-icon"></span>
                </button>

                <!-- Logo -->
                <div class="logo">
                    <a class="logo-wrap" href="<?php echo site_url();?>">
                        <img class="logo-img logo-img-main" src="<?php echo get_stylesheet_directory_uri(); ?>/img/logo-2b.png" alt="Alhashemia Logo">
                        <img class="logo-img logo-img-active" src="<?php echo get_stylesheet_directory_uri(); ?>/img/logo-1b.png" alt="Alhashemia Logo">
                    </a>
                </div>
                <!-- End Logo -->
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse nav-collapse">
                <div class="menu-container">
                    <ul class="navbar-nav navbar-nav-right">
                        <li class="nav-item"><a class="nav-item-child nav-item-hover active" href="<?php echo site_url();?>">Home</a></li>
                        <li class="nav-item"><a class="nav-item-child nav-item-hover" href="<?php echo site_url();?>/about-us/">About Us</a></li>
                        <li class="nav-item"><a class="nav-item-child nav-item-hover" href="<?php echo site_url();?>/subsidiaries/">Subsidiaries</a></li>
                        <li class="nav-item"><a class="nav-item-child nav-item-hover" href="<?php echo site_url();?>/careers/">Careers</a></li>
                        <li class="nav-item"><a class="nav-item-child nav-item-hover" href="<?php echo site_url();?>/contact/">Contact Us</a></li>
                    </ul>
                </div>
            </div>
            <!-- End Navbar Collapse -->
        </div>
    </nav>
    <!-- Navbar -->
</header>
<!--========== END HEADER ==========-->