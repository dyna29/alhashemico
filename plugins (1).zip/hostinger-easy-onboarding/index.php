<?php
/** Silence is golden. **/
