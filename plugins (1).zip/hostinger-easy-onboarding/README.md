# Hostinger wordpress plugin

## CLI Commands

== Usage ==

## Build Commands

### Install packages

$ npm install

### Compiling Assets

$ npm run prod

## Gutenberg Blocks

$ cd gutenberg/edit-pages-panel

### Install packages

$ npm install

### Compiling Assets

$ npm run build

### Watch Assets

$ npm run start
