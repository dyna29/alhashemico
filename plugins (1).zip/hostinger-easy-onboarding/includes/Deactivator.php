<?php

namespace Hostinger\EasyOnboarding;

defined( 'ABSPATH' ) || exit;

class Deactivator {
	public static function deactivate(): void {
	}
}
