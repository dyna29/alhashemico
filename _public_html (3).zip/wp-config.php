<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u806441573_gx3rZ' );

/** Database username */
define( 'DB_USER', 'u806441573_0M8qq' );

/** Database password */
define( 'DB_PASSWORD', 'WOcfestKhY' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'OdF-h0f5PU[gdMnpN,O5`TgVf&|6p!]{1t[J)0 m~Q_T/w#*::]0{FFIG_BH#Jc#' );
define( 'SECURE_AUTH_KEY',   '25x Mn,s%ka;Ps|8NfSsfo/</S *h^J>6h{<+3;8%_|[lr;</|y{wcBJ]/3GZ6{^' );
define( 'LOGGED_IN_KEY',     'oM-AQqs2O;8={:sQec *bl9DTC|%(!qU0uV>V3ipUmx|ckk<2FXi=C0o.0}<|h.K' );
define( 'NONCE_KEY',         '3{:!p16LR/e)Z$a8oZD_,Wh_IDMfku3jrJE*=^~6/.&J6TVRgKf3)P,Q/u&k=xFR' );
define( 'AUTH_SALT',         '=Ku4$f*jfdQ1l[trLZ|#nm/UTJaI27)-k@W-,ksq0bmHjdSK0M8~[FpyL5PF~?N)' );
define( 'SECURE_AUTH_SALT',  'Nfvi|&Mw#OM!%&r7voN|=+l!Gr%arUz>7CU&e}o2oatiF9$aW)=Z@8wf)E0UofxP' );
define( 'LOGGED_IN_SALT',    '10)1*IQ^q5I CGm!K?)H$`v)lyq?K1n&]L>Du`jrXYqdHkRw%wm=^GU0G%{1A_$m' );
define( 'NONCE_SALT',        'G=%TOQ 1RH1>LYPocuc8yaA.I-HP+u9pPVI8d5;|:Ay)%_cbQ9PU=Ay3?*0fyeE,' );
define( 'WP_CACHE_KEY_SALT', '`?~6Wkj&@5I`xgxP$!0DQ`j}y;o//1]<YF,~8.%9,jtoM!^.Y%pw9-6i6e?&xNX$' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'FS_METHOD', 'direct' );
define( 'COOKIEHASH', 'f95045ce83f3707a0092768ba2584bec' );
define( 'WP_AUTO_UPDATE_CORE', false );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
